(() => {
    'use strict';

    const SF = window.simpleFrameworks;
    if (!SF) {
        console.error('[SFCompat] simpleFrameworks is unavailable; compatibility layer not installed.');
        return;
    }

    const compat = SF.compat = SF.compat || {};
    compat.target = 'DoL 0.5.10.12 / ML 2.101.1';
    compat.revision = 'r1';

    function safeWiki(target, source) {
        if (!target || !source) return;
        try {
            if (typeof Wikifier === 'function') {
                new Wikifier(target, source);
            } else if (window.jQuery && typeof window.jQuery(target).wiki === 'function') {
                window.jQuery(target).wiki(source);
            }
        } catch (error) {
            console.error('[SFCompat] wikify failed:', source, error);
        }
    }

    function closeCompatOverlay() {
        const backdrop = document.getElementById('sf-compat-overlay-backdrop');
        if (backdrop) backdrop.remove();
        compat.currentOverlay = null;
    }

    function openCompatOverlay(key) {
        if (!key) return;
        if (compat.currentOverlay === key && document.getElementById('sf-compat-overlay-backdrop')) {
            closeCompatOverlay();
            return;
        }

        closeCompatOverlay();

        const backdrop = document.createElement('div');
        backdrop.id = 'sf-compat-overlay-backdrop';
        backdrop.setAttribute('data-sf-overlay', String(key));

        const panel = document.createElement('div');
        panel.id = 'sf-compat-overlay';
        panel.setAttribute('role', 'dialog');
        panel.setAttribute('aria-modal', 'true');

        const close = document.createElement('button');
        close.id = 'sf-compat-overlay-close';
        close.type = 'button';
        close.textContent = '×';
        close.setAttribute('aria-label', 'Close');
        close.addEventListener('click', closeCompatOverlay);

        const content = document.createElement('div');
        content.id = 'sf-compat-overlay-content';

        panel.append(close, content);
        backdrop.appendChild(panel);
        document.body.appendChild(backdrop);
        backdrop.addEventListener('click', event => {
            if (event.target === backdrop) closeCompatOverlay();
        });

        compat.currentOverlay = key;
        safeWiki(content, `<<${key}>>`);
    }

    function enableDrag(element, handle) {
        if (!element || !handle || element.dataset.sfNativeDrag === '1') return;
        element.dataset.sfNativeDrag = '1';
        handle.style.touchAction = 'none';

        let active = false;
        let pointerId = null;
        let dx = 0;
        let dy = 0;

        handle.addEventListener('pointerdown', event => {
            if (event.button !== undefined && event.button !== 0) return;
            const rect = element.getBoundingClientRect();
            active = true;
            pointerId = event.pointerId;
            dx = event.clientX - rect.left;
            dy = event.clientY - rect.top;
            element.style.position = 'fixed';
            element.style.margin = '0';
            try { handle.setPointerCapture(pointerId); } catch (_) {}
            event.preventDefault();
        });

        handle.addEventListener('pointermove', event => {
            if (!active || event.pointerId !== pointerId) return;
            const maxX = Math.max(0, window.innerWidth - Math.min(element.offsetWidth, window.innerWidth));
            const maxY = Math.max(0, window.innerHeight - Math.min(element.offsetHeight, window.innerHeight));
            const x = Math.min(maxX, Math.max(0, event.clientX - dx));
            const y = Math.min(maxY, Math.max(0, event.clientY - dy));
            element.style.left = `${x}px`;
            element.style.top = `${y}px`;
        });

        const stop = event => {
            if (!active || event.pointerId !== pointerId) return;
            active = false;
            try { handle.releasePointerCapture(pointerId); } catch (_) {}
            pointerId = null;
        };
        handle.addEventListener('pointerup', stop);
        handle.addEventListener('pointercancel', stop);
    }

    const sidebarZones = [
        ['sf-mod-caption-description', 'ModCaptionDescription'],
        ['sf-mod-status-bar', 'ModStatusBar'],
        ['sf-mod-menu-big', 'ModMenuBig'],
        ['sf-mod-menu-small', 'ModMenuSmall'],
        ['sf-mod-caption-after-description', 'ModCaptionAfterDescription']
    ];

    function mountSidebarHooks() {
        const storyCaption = document.getElementById('story-caption');
        if (!storyCaption) return;

        // The 2.0.5 implementation wrapped a moving chunk of StoryCaption in a new DIV.
        // On 0.5.10.12 that corrupts the sidebar DOM.  Keep the original DOM untouched and
        // mount an isolated hook host at the end instead.
        let host = document.getElementById('sf-compat-sidebar-hooks');
        if (!host || host.parentElement !== storyCaption) {
            host?.remove();
            host = document.createElement('div');
            host.id = 'sf-compat-sidebar-hooks';
            storyCaption.appendChild(host);
        }

        host.replaceChildren();
        for (const [id, widget] of sidebarZones) {
            const zone = document.createElement('div');
            zone.id = id;
            zone.className = 'sf-compat-zone';
            host.appendChild(zone);
            safeWiki(zone, `<<${widget}>>`);
        }
    }

    compat.openOverlay = openCompatOverlay;
    compat.closeOverlay = closeCompatOverlay;
    compat.enableDrag = enableDrag;
    compat.mountSidebarHooks = mountSidebarHooks;

    function scheduleSidebarMount() {
        window.setTimeout(mountSidebarHooks, 0);
    }

    if (window.jQuery) {
        window.jQuery(document)
            .off(':passagedisplay.sfcompat')
            .on(':passagedisplay.sfcompat', scheduleSidebarMount);
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', scheduleSidebarMount, { once: true });
    } else {
        scheduleSidebarMount();
    }

    console.info('[SFCompat] installed:', compat.target, compat.revision);
})();
